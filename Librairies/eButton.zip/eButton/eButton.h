#define ButtonDelay  300 // Delay in milliseconds

// Defines the possible output of the Button.press function
enum ButtonOutput
{
  None,
  Simple,
  Long
};

// Defines the Button class
class eButton
{
  public:
    bool pressed = false;
    bool wasPressed = false;
    unsigned long pressedTime = 0;
    unsigned long lastTime = 0;
    unsigned long longPushCounter = 0;

  public:
    ButtonOutput press(int input)
    {
      ButtonOutput out = None;
      unsigned long t = millis();
      
      if (input)
      {
        if (wasPressed)
        {
        	longPushCounter += t - lastTime;

            if (longPushCounter >= ButtonDelay)
            {
          	  out = Long;

              longPushCounter = 0;
            }
        }
        else 
        {
       		if (t - pressedTime >= ButtonDelay)
       		{
       			out = Simple;
          
          		pressedTime = t;
            }
        }
      }
      
      wasPressed = input;
      lastTime = t;

      if (input == 0)
      	longPushCounter = 0;

      return out;
    }
};
